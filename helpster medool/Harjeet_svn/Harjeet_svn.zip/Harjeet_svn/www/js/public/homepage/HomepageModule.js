angular.module('HomepageModule', ['toastr', 'compareTo']);


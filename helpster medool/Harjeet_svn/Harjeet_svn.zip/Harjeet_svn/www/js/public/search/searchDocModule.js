angular.module('searchDoc', ['rzModule', 'ui.bootstrap']);
//angular.module('searchDoc');

